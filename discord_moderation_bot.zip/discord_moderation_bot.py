import discord
from discord.ext import commands, tasks
import asyncio
from datetime import datetime, timedelta
import json
import os
from collections import defaultdict
import re

# ボットの設定
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.moderation = True

bot = commands.Bot(command_prefix='!', intents=intents)

# データ保存用
class ModerationData:
    def __init__(self):
        self.warnings = defaultdict(list)
        self.mutes = {}
        self.bans = {}
        self.spam_count = defaultdict(int)
        self.last_message_time = {}
        self.user_profiles = {}
        self.bad_words = set()
        self.load_bad_words()
    
    def load_bad_words(self):
        """禁止ワードリストを読み込む"""
        default_bad_words = {
            'spam', 'porn', 'xxx', 'hentai', 'nsfw',  # 例
        }
        self.bad_words = default_bad_words
    
    def save_data(self):
        """データを保存"""
        data = {
            'warnings': dict(self.warnings),
            'mutes': self.mutes,
            'bans': self.bans,
            'user_profiles': self.user_profiles
        }
        with open('moderation_data.json', 'w') as f:
            json.dump(data, f, default=str, indent=2)
    
    def load_data(self):
        """データを読み込む"""
        try:
            with open('moderation_data.json', 'r') as f:
                data = json.load(f)
                self.warnings = defaultdict(list, data.get('warnings', {}))
                self.mutes = data.get('mutes', {})
                self.bans = data.get('bans', {})
                self.user_profiles = data.get('user_profiles', {})
        except FileNotFoundError:
            pass

mod_data = ModerationData()

class SpamDetector:
    """スパム検出システム"""
    def __init__(self):
        self.message_history = defaultdict(list)
        self.embed_spam_count = defaultdict(int)
        self.mention_spam_count = defaultdict(int)
    
    def check_spam(self, message):
        """スパムを検出"""
        user_id = str(message.author.id)
        current_time = datetime.now()
        
        # メッセージ履歴の管理
        self.message_history[user_id] = [
            msg_time for msg_time in self.message_history[user_id]
            if (current_time - msg_time).seconds < 10
        ]
        self.message_history[user_id].append(current_time)
        
        # 10秒以内に5つ以上のメッセージ
        if len(self.message_history[user_id]) > 5:
            return True, "メッセージスパム"
        
        # 短時間に大量のメンション
        if message.mentions and len(message.mentions) > 5:
            self.mention_spam_count[user_id] += 1
            if self.mention_spam_count[user_id] > 3:
                return True, "メンションスパム"
        else:
            self.mention_spam_count[user_id] = 0
        
        # 大量のEmbed
        if len(message.embeds) > 3:
            self.embed_spam_count[user_id] += 1
            if self.embed_spam_count[user_id] > 2:
                return True, "Embedスパム"
        
        # キャップスロック（大文字）が70%以上
        if len(message.content) > 10:
            uppercase_count = sum(1 for c in message.content if c.isupper())
            if uppercase_count / len(message.content) > 0.7:
                return True, "キャップスロック連発"
        
        # 絵文字スパム
        emoji_pattern = r'[😀-🙏🌀-🗿🚀-🛿]'
        emoji_count = len(re.findall(emoji_pattern, message.content))
        if emoji_count > 15:
            return True, "絵文字スパム"
        
        return False, None
    
    def reset_spam_count(self, user_id):
        """スパムカウントをリセット"""
        self.mention_spam_count[str(user_id)] = 0
        self.embed_spam_count[str(user_id)] = 0

spam_detector = SpamDetector()

@bot.event
async def on_ready():
    """ボット起動時"""
    print(f'{bot.user} でログインしました')
    mod_data.load_data()
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching,
        name="サーバーの安全 | !help"
    ))
    check_mute_expiry.start()
    check_ban_expiry.start()

@bot.event
async def on_message(message):
    """メッセージ監視"""
    if message.author.bot:
        await bot.process_commands(message)
        return
    
    # スパム検出
    is_spam, reason = spam_detector.check_spam(message)
    if is_spam and not message.author.guild_permissions.administrator:
        try:
            await message.delete()
            warning_embed = discord.Embed(
                title="⚠️ メッセージ削除",
                description=f"理由: {reason}",
                color=discord.Color.orange()
            )
            await message.author.send(embed=warning_embed)
            mod_data.warnings[str(message.author.id)].append({
                'reason': reason,
                'timestamp': datetime.now().isoformat(),
                'guild': message.guild.id
            })
            return
        except:
            pass
    
    # 禁止ワード検出
    for bad_word in mod_data.bad_words:
        if bad_word.lower() in message.content.lower():
            try:
                await message.delete()
                await message.author.send("禁止されている言葉が含まれています")
                mod_data.warnings[str(message.author.id)].append({
                    'reason': '禁止ワード検出',
                    'timestamp': datetime.now().isoformat(),
                    'guild': message.guild.id
                })
                return
            except:
                pass
    
    # プロフィール情報を記録
    user_id = str(message.author.id)
    if user_id not in mod_data.user_profiles:
        mod_data.user_profiles[user_id] = {
            'username': message.author.name,
            'discriminator': str(message.author.discriminator),
            'first_seen': datetime.now().isoformat()
        }
    
    await bot.process_commands(message)

@bot.event
async def on_member_join(member):
    """ユーザー参加時"""
    embed = discord.Embed(
        title="✅ ユーザー参加",
        description=f"{member.mention} がサーバーに参加しました",
        color=discord.Color.green()
    )
    embed.add_field(name="ユーザータグ", value=f"{member.name}#{member.discriminator}")
    embed.add_field(name="アカウント作成日", value=member.created_at.strftime('%Y-%m-%d'))
    embed.add_field(name="ID", value=member.id)
    
    # ログチャネルがあれば送信
    for channel in member.guild.text_channels:
        if channel.name == 'moderation-logs':
            await channel.send(embed=embed)
            break

@bot.event
async def on_member_remove(member):
    """ユーザー退出時"""
    embed = discord.Embed(
        title="❌ ユーザー退出",
        description=f"{member.name}#{member.discriminator} がサーバーを退出しました",
        color=discord.Color.red()
    )
    embed.add_field(name="ID", value=member.id)
    
    for channel in member.guild.text_channels:
        if channel.name == 'moderation-logs':
            await channel.send(embed=embed)
            break

# === モデレーションコマンド ===

@bot.command(name='warn', help='ユーザーに警告を与える')
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason="理由なし"):
    """警告を記録"""
    if member == ctx.author:
        await ctx.send("自分自身に警告を与えることはできません")
        return
    
    if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
        await ctx.send("このユーザーに警告を与える権限がありません")
        return
    
    user_id = str(member.id)
    mod_data.warnings[user_id].append({
        'reason': reason,
        'timestamp': datetime.now().isoformat(),
        'moderator': ctx.author.name,
        'guild': ctx.guild.id
    })
    
    warn_count = len(mod_data.warnings[user_id])
    
    embed = discord.Embed(
        title="⚠️ 警告",
        description=f"{member.mention} に警告を与えました",
        color=discord.Color.orange()
    )
    embed.add_field(name="理由", value=reason)
    embed.add_field(name="警告回数", value=f"{warn_count}/3")
    embed.add_field(name="モデレーター", value=ctx.author.mention)
    
    await ctx.send(embed=embed)
    
    try:
        await member.send(f"警告を受けました: {reason}")
    except:
        pass
    
    # 3回目の警告でミュート
    if warn_count >= 3:
        await mute_user(ctx, member, "警告3回到達")
    
    mod_data.save_data()

@bot.command(name='mute', help='ユーザーをミュート')
@commands.has_permissions(manage_roles=True)
async def mute_command(ctx, member: discord.Member, duration: int = 60, *, reason="理由なし"):
    """ユーザーをミュート（デフォルト60分）"""
    await mute_user(ctx, member, reason, duration)

async def mute_user(ctx, member: discord.Member, reason: str, duration: int = 60):
    """ユーザーをミュート"""
    muted_role = None
    for role in ctx.guild.roles:
        if role.name == "Muted":
            muted_role = role
            break
    
    if not muted_role:
        muted_role = await ctx.guild.create_role(name="Muted")
        for channel in ctx.guild.channels:
            await channel.set_permissions(muted_role, send_messages=False, speak=False)
    
    try:
        await member.add_roles(muted_role)
    except:
        pass
    
    mute_until = datetime.now() + timedelta(minutes=duration)
    mod_data.mutes[str(member.id)] = {
        'until': mute_until.isoformat(),
        'reason': reason,
        'guild': ctx.guild.id
    }
    
    embed = discord.Embed(
        title="🔇 ミュート",
        description=f"{member.mention} をミュートしました",
        color=discord.Color.red()
    )
    embed.add_field(name="理由", value=reason)
    embed.add_field(name="期間", value=f"{duration}分")
    embed.add_field(name="解除予定", value=mute_until.strftime('%Y-%m-%d %H:%M:%S'))
    
    await ctx.send(embed=embed)
    
    try:
        await member.send(f"ミュートされました: {reason}\n解除予定: {mute_until.strftime('%Y-%m-%d %H:%M:%S')}")
    except:
        pass
    
    mod_data.save_data()

@bot.command(name='unmute', help='ユーザーのミュートを解除')
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    """ミュート解除"""
    muted_role = None
    for role in ctx.guild.roles:
        if role.name == "Muted":
            muted_role = role
            break
    
    if not muted_role:
        await ctx.send("Muted ロールが見つかりません")
        return
    
    try:
        await member.remove_roles(muted_role)
    except:
        pass
    
    if str(member.id) in mod_data.mutes:
        del mod_data.mutes[str(member.id)]
    
    embed = discord.Embed(
        title="🔊 ミュート解除",
        description=f"{member.mention} のミュートを解除しました",
        color=discord.Color.green()
    )
    await ctx.send(embed=embed)
    
    try:
        await member.send("ミュートが解除されました")
    except:
        pass
    
    mod_data.save_data()

@bot.command(name='ban', help='ユーザーをバン')
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, duration: int = 0, *, reason="理由なし"):
    """ユーザーをバン（duration=0で永続）"""
    if member == ctx.author:
        await ctx.send("自分自身をバンすることはできません")
        return
    
    if member.top_role >= ctx.author.top_role and ctx.author != ctx.guild.owner:
        await ctx.send("このユーザーをバンする権限がありません")
        return
    
    try:
        await ctx.guild.ban(member, reason=reason)
    except:
        await ctx.send("バンに失敗しました")
        return
    
    ban_until = None
    if duration > 0:
        ban_until = (datetime.now() + timedelta(hours=duration)).isoformat()
    
    mod_data.bans[str(member.id)] = {
        'until': ban_until,
        'reason': reason,
        'guild': ctx.guild.id
    }
    
    embed = discord.Embed(
        title="🔨 バン",
        description=f"{member.mention} をバンしました",
        color=discord.Color.dark_red()
    )
    embed.add_field(name="理由", value=reason)
    if duration > 0:
        embed.add_field(name="期間", value=f"{duration}時間")
    else:
        embed.add_field(name="期間", value="永続")
    
    await ctx.send(embed=embed)
    mod_data.save_data()

@bot.command(name='kick', help='ユーザーをキック')
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="理由なし"):
    """ユーザーをキック"""
    if member == ctx.author:
        await ctx.send("自分自身をキックすることはできません")
        return
    
    try:
        await member.kick(reason=reason)
        embed = discord.Embed(
            title="👢 キック",
            description=f"{member.mention} をキックしました",
            color=discord.Color.orange()
        )
        embed.add_field(name="理由", value=reason)
        await ctx.send(embed=embed)
    except:
        await ctx.send("キックに失敗しました")

@bot.command(name='warnings', help='ユーザーの警告を表示')
@commands.has_permissions(manage_messages=True)
async def warnings(ctx, member: discord.Member = None):
    """警告履歴を表示"""
    if member is None:
        member = ctx.author
    
    user_id = str(member.id)
    user_warnings = mod_data.warnings.get(user_id, [])
    
    embed = discord.Embed(
        title=f"⚠️ {member.name} の警告履歴",
        color=discord.Color.orange()
    )
    
    if not user_warnings:
        embed.description = "警告がありません"
    else:
        for i, warning in enumerate(user_warnings, 1):
            embed.add_field(
                name=f"警告 #{i}",
                value=f"理由: {warning['reason']}\n日時: {warning['timestamp'][:10]}",
                inline=False
            )
    
    await ctx.send(embed=embed)

@bot.command(name='clear', help='メッセージを削除')
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int = 10):
    """メッセージを一括削除"""
    if amount > 100:
        amount = 100
    
    deleted = await ctx.channel.purge(limit=amount + 1)
    
    embed = discord.Embed(
        title="🗑️ メッセージ削除",
        description=f"{len(deleted) - 1}件のメッセージを削除しました",
        color=discord.Color.red()
    )
    
    msg = await ctx.send(embed=embed)
    await asyncio.sleep(3)
    await msg.delete()

@bot.command(name='slowmode', help='スローモードを設定')
@commands.has_permissions(manage_channels=True)
async def slowmode(ctx, seconds: int = 0):
    """スローモードを設定"""
    if seconds > 21600:  # 6時間
        seconds = 21600
    
    try:
        await ctx.channel.edit(slowmode_delay=seconds)
        embed = discord.Embed(
            title="⏱️ スローモード",
            description=f"スローモードを {seconds}秒に設定しました",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)
    except:
        await ctx.send("スローモードの設定に失敗しました")

@bot.command(name='lock', help='チャンネルをロック')
@commands.has_permissions(manage_channels=True)
async def lock(ctx):
    """チャンネルをロック"""
    try:
        await ctx.channel.edit(overwrites={
            ctx.guild.default_role: discord.PermissionOverwrite(send_messages=False)
        })
        embed = discord.Embed(
            title="🔒 チャンネルロック",
            description="このチャンネルをロックしました",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
    except:
        await ctx.send("ロックに失敗しました")

@bot.command(name='unlock', help='チャンネルのロックを解除')
@commands.has_permissions(manage_channels=True)
async def unlock(ctx):
    """チャンネルのロック解除"""
    try:
        await ctx.channel.edit(overwrites={
            ctx.guild.default_role: discord.PermissionOverwrite(send_messages=True)
        })
        embed = discord.Embed(
            title="🔓 チャンネルロック解除",
            description="このチャンネルのロックを解除しました",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    except:
        await ctx.send("ロック解除に失敗しました")

@bot.command(name='info', help='ユーザー情報を表示')
async def info(ctx, member: discord.Member = None):
    """ユーザー情報を表示"""
    if member is None:
        member = ctx.author
    
    embed = discord.Embed(
        title=f"{member.name}#{member.discriminator}",
        color=discord.Color.blue()
    )
    embed.set_thumbnail(url=member.avatar.url if member.avatar else None)
    embed.add_field(name="ID", value=member.id)
    embed.add_field(name="アカウント作成", value=member.created_at.strftime('%Y-%m-%d'))
    embed.add_field(name="サーバー参加", value=member.joined_at.strftime('%Y-%m-%d') if member.joined_at else "不明")
    embed.add_field(name="ロール", value=" ".join([role.mention for role in member.roles[1:]]) or "なし")
    embed.add_field(name="警告数", value=len(mod_data.warnings.get(str(member.id), [])))
    embed.add_field(name="Bot", value="はい" if member.bot else "いいえ")
    
    await ctx.send(embed=embed)

@bot.command(name='serverinfo', help='サーバー情報を表示')
async def serverinfo(ctx):
    """サーバー情報を表示"""
    guild = ctx.guild
    embed = discord.Embed(
        title=guild.name,
        color=discord.Color.purple()
    )
    embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
    embed.add_field(name="ID", value=guild.id)
    embed.add_field(name="所有者", value=guild.owner.mention if guild.owner else "不明")
    embed.add_field(name="メンバー数", value=guild.member_count)
    embed.add_field(name="テキストチャンネル", value=len(guild.text_channels))
    embed.add_field(name="ボイスチャンネル", value=len(guild.voice_channels))
    embed.add_field(name="ロール数", value=len(guild.roles))
    embed.add_field(name="作成日", value=guild.created_at.strftime('%Y-%m-%d'))
    
    await ctx.send(embed=embed)

@bot.command(name='addbadword', help='禁止ワードを追加')
@commands.has_permissions(manage_messages=True)
async def addbadword(ctx, *, word):
    """禁止ワードを追加"""
    mod_data.bad_words.add(word.lower())
    embed = discord.Embed(
        title="➕ 禁止ワード追加",
        description=f"'{word}' を禁止ワードリストに追加しました",
        color=discord.Color.green()
    )
    await ctx.send(embed=embed)

@bot.command(name='removebadword', help='禁止ワードを削除')
@commands.has_permissions(manage_messages=True)
async def removebadword(ctx, *, word):
    """禁止ワードを削除"""
    if word.lower() in mod_data.bad_words:
        mod_data.bad_words.remove(word.lower())
        embed = discord.Embed(
            title="➖ 禁止ワード削除",
            description=f"'{word}' を禁止ワードリストから削除しました",
            color=discord.Color.red()
        )
    else:
        embed = discord.Embed(
            title="❌ エラー",
            description=f"'{word}' は禁止ワードリストに存在しません",
            color=discord.Color.red()
        )
    await ctx.send(embed=embed)

# === 定期タスク ===

@tasks.loop(minutes=1)
async def check_mute_expiry():
    """ミュート期限をチェック"""
    current_time = datetime.now()
    expired = []
    
    for user_id, mute_info in mod_data.mutes.items():
        if mute_info['until']:
            mute_until = datetime.fromisoformat(mute_info['until'])
            if current_time > mute_until:
                expired.append(user_id)
    
    for user_id in expired:
        del mod_data.mutes[user_id]
    
    if expired:
        mod_data.save_data()

@tasks.loop(hours=1)
async def check_ban_expiry():
    """バン期限をチェック"""
    current_time = datetime.now()
    expired = []
    
    for user_id, ban_info in mod_data.bans.items():
        if ban_info['until']:
            ban_until = datetime.fromisoformat(ban_info['until'])
            if current_time > ban_until:
                expired.append(user_id)
    
    for user_id in expired:
        del mod_data.bans[user_id]
    
    if expired:
        mod_data.save_data()

@bot.command(name='help', help='ヘルプを表示')
async def help_command(ctx):
    """ヘルプを表示"""
    embed = discord.Embed(
        title="🤖 モデレーションボット ヘルプ",
        color=discord.Color.blue(),
        description="完全な荒らし対策ボット"
    )
    
    embed.add_field(
        name="⚠️ 警告コマンド",
        value="""
        `!warn @user [理由]` - ユーザーに警告を与える
        `!warnings [@user]` - 警告履歴を表示
        """,
        inline=False
    )
    
    embed.add_field(
        name="🔇 ミュートコマンド",
        value="""
        `!mute @user [分] [理由]` - ユーザーをミュート
        `!unmute @user` - ミュートを解除
        """,
        inline=False
    )
    
    embed.add_field(
        name="🔨 バンコマンド",
        value="""
        `!ban @user [時間] [理由]` - ユーザーをバン
        `!kick @user [理由]` - ユーザーをキック
        """,
        inline=False
    )
    
    embed.add_field(
        name="🗑️ メッセージコマンド",
        value="""
        `!clear [数]` - メッセージを削除
        `!slowmode [秒]` - スローモードを設定
        """,
        inline=False
    )
    
    embed.add_field(
        name="🔒 チャンネルコマンド",
        value="""
        `!lock` - チャンネルをロック
        `!unlock` - チャンネルのロック解除
        """,
        inline=False
    )
    
    embed.add_field(
        name="🔤 禁止ワード",
        value="""
        `!addbadword [ワード]` - 禁止ワードを追加
        `!removebadword [ワード]` - 禁止ワードを削除
        """,
        inline=False
    )
    
    embed.add_field(
        name="ℹ️ 情報コマンド",
        value="""
        `!info [@user]` - ユーザー情報を表示
        `!serverinfo` - サーバー情報を表示
        """,
        inline=False
    )
    
    embed.set_footer(text="管理者権限が必要なコマンドがあります")
    await ctx.send(embed=embed)

# ボット起動
if __name__ == "__main__":
    TOKEN = "YOUR_BOT_TOKEN_HERE"  # トークンをここに入力
    bot.run(TOKEN)
