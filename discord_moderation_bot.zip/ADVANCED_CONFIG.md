# Discord 荒らし対策ボット - 高度な設定ガイド

## 🔧 環境変数の設定（推奨）

### .env ファイルを使用した安全なトークン管理

`discord_moderation_bot.py` の最後の部分を以下に置き換えます：

```python
from dotenv import load_dotenv
import os

# .env ファイルを読み込む
load_dotenv()

if __name__ == "__main__":
    TOKEN = os.getenv('DISCORD_TOKEN')
    if not TOKEN:
        raise ValueError("DISCORD_TOKEN が .env ファイルに設定されていません")
    bot.run(TOKEN)
```

`.env` ファイルを作成し、以下を記入：
```
DISCORD_TOKEN=YOUR_BOT_TOKEN_HERE
```

---

## 🎯 スパム検出の詳細設定

### 1. メッセージレート制限の調整

```python
# SpamDetector クラスの check_spam メソッド内

# 例: 10秒以内に3つ以上でスパム判定
time_window = 10  # 秒
max_messages = 3

self.message_history[user_id] = [
    msg_time for msg_time in self.message_history[user_id]
    if (current_time - msg_time).seconds < time_window
]

if len(self.message_history[user_id]) > max_messages:
    return True, f"{time_window}秒以内に{max_messages}つ以上のメッセージ"
```

### 2. キャップスロック感度の変更

```python
# 大文字の割合を変更（デフォルト: 70%）
uppercase_ratio = 0.8  # 80%以上で検出

if len(message.content) > 10:
    uppercase_count = sum(1 for c in message.content if c.isupper())
    if uppercase_count / len(message.content) > uppercase_ratio:
        return True, "キャップスロック連発"
```

### 3. 絵文字スパムの制限

```python
# 最大絵文字数を変更（デフォルト: 15）
max_emojis = 10

emoji_count = len(re.findall(emoji_pattern, message.content))
if emoji_count > max_emojis:
    return True, f"絵文字スパム（{max_emojis}個以上）"
```

---

## 📊 カスタム警告レベルシステム

より複雑な警告システムの実装例：

```python
class AdvancedWarningSystem:
    """高度な警告システム"""
    WARNING_LEVELS = {
        'low': {'points': 1, 'duration': timedelta(days=7)},
        'medium': {'points': 2, 'duration': timedelta(days=30)},
        'high': {'points': 3, 'duration': timedelta(days=90)},
    }
    
    def __init__(self):
        self.user_points = defaultdict(int)
    
    def add_warning(self, user_id, level='medium'):
        """警告ポイントを追加"""
        points = self.WARNING_LEVELS[level]['points']
        self.user_points[user_id] += points
        return self.user_points[user_id]
    
    def get_action(self, total_points):
        """ポイントに基づいてアクションを決定"""
        if total_points >= 9:
            return 'ban', '永続バン'
        elif total_points >= 6:
            return 'ban_temp', '7日間の一時バン'
        elif total_points >= 3:
            return 'mute', '3日間のミュート'
        return 'warn', '警告のみ'
```

---

## 🔍 高度なフィルター機能

### URL フィルター

```python
@bot.event
async def on_message(message):
    if message.author.bot:
        return
    
    # 危険なURL パターンを検出
    dangerous_url_patterns = [
        r'http[s]?://.*\.(bit\.ly|tinyurl\.com|goo\.gl)',  # 短縮URL
        r'discord\.(gg|com)',  # 他のサーバー招待
        r'youtube\.com.*viral',  # 疑わしいリンク
    ]
    
    for pattern in dangerous_url_patterns:
        if re.search(pattern, message.content):
            await message.delete()
            await message.author.send("疑わしいリンクが検出されました")
            return
    
    await bot.process_commands(message)
```

### イメージのNSFW検出（オプション）

```python
# OpenAI Vision API を使用した実装例
import aiohttp

async def check_image_safety(image_url):
    """画像の安全性をチェック"""
    # 実装にはOpenAI APIキーが必要です
    async with aiohttp.ClientSession() as session:
        # APIに送信してNSFWチェック
        # 実装詳細は省略
        pass
```

---

## 📈 統計とアナリティクス

### ダッシュボード用の統計情報

```python
class ModerationAnalytics:
    """モデレーション統計"""
    def __init__(self):
        self.stats = {
            'warnings_issued': 0,
            'mutes_issued': 0,
            'bans_issued': 0,
            'messages_deleted': 0,
            'spam_detected': 0
        }
    
    def get_daily_report(self):
        """日次レポートを生成"""
        return f"""
        📊 モデレーション統計（本日）
        ⚠️  警告: {self.stats['warnings_issued']}件
        🔇 ミュート: {self.stats['mutes_issued']}件
        🔨 バン: {self.stats['bans_issued']}件
        🗑️  削除メッセージ: {self.stats['messages_deleted']}件
        🚨 スパム検出: {self.stats['spam_detected']}件
        """

@bot.command(name='stats')
@commands.has_permissions(manage_guild=True)
async def show_stats(ctx):
    """統計情報を表示"""
    embed = discord.Embed(
        title="📊 モデレーション統計",
        color=discord.Color.blue()
    )
    # 統計情報を追加
    await ctx.send(embed=embed)
```

---

## 🎮 ロールベースのアクセス制御

```python
class RoleBasedPermissions:
    """ロールベースのアクセス制御"""
    ROLE_PERMISSIONS = {
        'Moderator': ['warn', 'mute', 'clear'],
        'Admin': ['warn', 'mute', 'ban', 'kick', 'clear'],
        'Owner': ['all']
    }
    
    @staticmethod
    def check_permission(user, command):
        """ユーザーがコマンドを実行できるかチェック"""
        for role in user.roles:
            if role.name in RoleBasedPermissions.ROLE_PERMISSIONS:
                permissions = RoleBasedPermissions.ROLE_PERMISSIONS[role.name]
                if 'all' in permissions or command in permissions:
                    return True
        return False

# コマンドで使用
@bot.command(name='warn')
async def warn_advanced(ctx, member: discord.Member, *, reason):
    if not RoleBasedPermissions.check_permission(ctx.author, 'warn'):
        await ctx.send("このコマンドを実行する権限がありません")
        return
    # 警告処理...
```

---

## 🔔 カスタム通知システム

### ユーザーへのDM通知テンプレート

```python
async def send_moderation_notice(user, action, reason, details=None):
    """モデレーション通知をユーザーに送信"""
    embed = discord.Embed(
        title=f"⚠️ モデレーション通知: {action}",
        description=f"理由: {reason}",
        color=discord.Color.orange(),
        timestamp=datetime.now()
    )
    
    if details:
        for key, value in details.items():
            embed.add_field(name=key, value=value, inline=False)
    
    embed.set_footer(text="このメッセージに返信できます")
    
    try:
        await user.send(embed=embed)
    except discord.Forbidden:
        print(f"Could not DM {user}")
```

---

## 🛠️ ロギングシステムの強化

```python
import logging
from logging.handlers import RotatingFileHandler

def setup_logging():
    """ロギングの設定"""
    logger = logging.getLogger('discord')
    logger.setLevel(logging.INFO)
    
    # ファイルハンドラ
    handler = RotatingFileHandler(
        'bot.log',
        maxBytes=5*1024*1024,  # 5MB
        backupCount=5
    )
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# ボット起動時に実行
setup_logging()
```

---

## 🔐 管理者ロールの自動作成

```python
async def setup_moderation_roles(guild):
    """モデレーション用ロールを自動作成"""
    roles_to_create = {
        'Muted': discord.Color.greyple(),
        'Moderator': discord.Color.blue(),
        'Senior Moderator': discord.Color.purple(),
    }
    
    for role_name, color in roles_to_create.items():
        try:
            existing = discord.utils.get(guild.roles, name=role_name)
            if not existing:
                await guild.create_role(
                    name=role_name,
                    color=color,
                    reason="モデレーション用ロール"
                )
                print(f"Created role: {role_name}")
        except discord.Forbidden:
            print(f"Could not create {role_name}")

# on_ready で実行
@bot.event
async def on_ready():
    for guild in bot.guilds:
        await setup_moderation_roles(guild)
```

---

## 🎯 自動モデレーション規則

```python
class AutoModerationRules:
    """自動モデレーション規則"""
    RULES = {
        'excessive_caps': {
            'enabled': True,
            'threshold': 0.7,
            'action': 'warn',
            'reason': 'キャップスロック連発'
        },
        'mention_spam': {
            'enabled': True,
            'threshold': 5,
            'action': 'mute',
            'reason': 'メンションスパム'
        },
        'message_spam': {
            'enabled': True,
            'threshold': 5,
            'action': 'warn',
            'reason': 'メッセージスパム'
        }
    }
    
    @staticmethod
    def get_action(violation_type):
        """違反タイプに対するアクションを取得"""
        rule = AutoModerationRules.RULES.get(violation_type)
        return rule['action'] if rule else None
```

---

## 📱 複数サーバー対応

```python
class ServerConfig:
    """サーバー別設定"""
    def __init__(self):
        self.configs = {}
    
    def get_config(self, guild_id):
        """サーバーの設定を取得"""
        return self.configs.get(guild_id, self.get_default_config())
    
    def set_config(self, guild_id, config):
        """サーバーの設定を保存"""
        self.configs[guild_id] = config
    
    @staticmethod
    def get_default_config():
        return {
            'prefix': '!',
            'log_channel': None,
            'mod_roles': [],
            'auto_mute_duration': 60,
            'warning_threshold': 3,
            'enable_auto_moderation': True
        }

server_config = ServerConfig()
```

---

## 📝 トラブルシューティング

### よくある問題と解決方法

**Q: ボットがメッセージを削除できない**
- A: ボットのロールが「Muted」ロールより上にあることを確認

**Q: スパム検出が敏感すぎる/甘い**
- A: `SpamDetector` クラスの閾値を調整

**Q: ミュートが解除されない**
- A: `check_mute_expiry()` タスクが実行されているか確認

---

## 🚀 本番環境へのデプロイ

### Heroku でのデプロイ例

1. `Procfile` を作成：
```
worker: python discord_moderation_bot.py
```

2. `runtime.txt` を作成：
```
python-3.11.4
```

3. Heroku CLI でデプロイ：
```bash
heroku login
heroku create your-bot-name
heroku config:set DISCORD_TOKEN=your_token
git push heroku main
```

---

このガイドを参考に、自分の需要に合わせてボットをカスタマイズしてください！
