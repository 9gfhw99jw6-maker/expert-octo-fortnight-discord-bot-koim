# 🤖 Discord 完全荒らし対策ボット

**すべての機能を詰め込んだ、本格的なDiscord荒らし対策・モデレーションボット**

---

## 📸 機能ハイライト

| 機能 | 説明 |
|------|------|
| 🛡️ **自動スパム検出** | メッセージスパム、メンションスパム、絵文字スパムを自動削除 |
| ⚠️ **警告システム** | 3段階警告システム（3回目で自動ミュート） |
| 🔇 **ミュート機能** | 時間指定可能なミュート（自動解除対応） |
| 🔨 **バン・キック** | 一時バン、永続バンに対応 |
| 🗑️ **メッセージ管理** | 一括削除、スローモード設定 |
| 🔒 **チャンネル保護** | 緊急ロック・ロック解除機能 |
| 🔤 **禁止ワードフィルター** | カスタム禁止ワード設定・自動削除 |
| 📊 **ログ機能** | 全モデレーション操作を自動記録 |
| 👥 **ユーザープロフィール記録** | 参加者情報を自動保存 |
| ℹ️ **情報表示** | ユーザー情報、サーバー情報表示 |

---

## 📁 ファイル構成

```
discord-moderation-bot/
├── discord_moderation_bot.py    # メインボットコード
├── requirements.txt               # Python依存ライブラリ
├── .env                           # 環境変数（トークン）
├── moderation_data.json           # 保存されたデータ
├── README.md                      # このファイル
├── SETUP_GUIDE.md                 # セットアップガイド
├── COMMAND_EXAMPLES.md            # コマンド実行例とシーン別対応
└── ADVANCED_CONFIG.md             # 高度な設定ガイド
```

---

## 🚀 クイックスタート

### 1️⃣ インストール

```bash
# リポジトリをクローン
git clone <repository-url>
cd discord-moderation-bot

# 依存ライブラリをインストール
pip install -r requirements.txt

# または
pip install discord.py==2.3.2 python-dotenv==1.0.0
```

### 2️⃣ ボットを作成・設定

1. [Discord Developer Portal](https://discord.com/developers/applications) にアクセス
2. **New Application** → ボット作成
3. **Bot** セクションでトークンを取得
4. `.env` ファイルを作成：
   ```
   DISCORD_TOKEN=your_token_here
   ```

### 3️⃣ ボットを起動

```bash
python discord_moderation_bot.py
```

✅ ボットがオンラインになればセットアップ完了！

---

## 📖 ドキュメント

### 🎯 SETUP_GUIDE.md
- 詳細なインストール手順
- 権限設定方法
- 基本的なトラブルシューティング
- 環境変数の安全な設定方法

### 💬 COMMAND_EXAMPLES.md
- **実際の使用例**が多数掲載
- シーン別対応マニュアル
- 緊急対応ガイド
- ベストプラクティス

### ⚙️ ADVANCED_CONFIG.md
- 高度なカスタマイズ方法
- スパム検出の感度調整
- 統計とアナリティクス
- Heroku へのデプロイ方法

---

## 🎮 主要コマンド

### ⚠️ 警告
```
!warn @user [理由]          # ユーザーに警告
!warnings [@user]           # 警告履歴を表示
```

### 🔇 ミュート
```
!mute @user [分] [理由]     # ユーザーをミュート
!unmute @user               # ミュートを解除
```

### 🔨 バン・キック
```
!ban @user [時間] [理由]    # ユーザーをバン
!kick @user [理由]          # ユーザーをキック
```

### 🗑️ メッセージ管理
```
!clear [数]                 # メッセージを削除
!slowmode [秒]              # スローモード設定
```

### 🔒 チャンネル保護
```
!lock                       # チャンネルをロック
!unlock                     # チャンネルのロック解除
```

### 🔤 禁止ワード
```
!addbadword [ワード]        # 禁止ワードを追加
!removebadword [ワード]     # 禁止ワードを削除
```

### ℹ️ 情報表示
```
!info [@user]               # ユーザー情報
!serverinfo                 # サーバー情報
!help                       # 全コマンド表示
```

---

## 🛡️ 自動荒らし対策

ボットは以下を**自動的に検出・削除**します：

| 検出対象 | 仕組み |
|---------|--------|
| **スパムメッセージ** | 10秒以内に5件以上のメッセージ |
| **メンションスパム** | 短時間に大量のメンション |
| **Embedスパム** | 3個以上のEmbed投稿 |
| **キャップスロック** | 文字の70%以上が大文字 |
| **絵文字スパム** | 15個以上の絵文字 |
| **禁止ワード** | カスタム禁止ワードリスト |

---

## 💾 データ管理

ボットは自動的に以下をJSON形式で保存します：

```json
{
  "warnings": {
    "user_id": [
      {
        "reason": "スパム",
        "timestamp": "2024-01-15T10:30:00",
        "moderator": "ModName",
        "guild": 123456789
      }
    ]
  },
  "mutes": {
    "user_id": {
      "until": "2024-01-15T11:30:00",
      "reason": "スパム",
      "guild": 123456789
    }
  },
  "user_profiles": {
    "user_id": {
      "username": "UserName",
      "first_seen": "2024-01-10T08:00:00"
    }
  }
}
```

---

## 🔐 セキュリティ

### ✅ セキュアな設定方法

```python
from dotenv import load_dotenv
import os

load_dotenv()  # .env ファイルから読み込み
TOKEN = os.getenv('DISCORD_TOKEN')
bot.run(TOKEN)
```

### ⚠️ 注意事項

- 🔑 **トークンを絶対に共有しないでください**
- 🔒 **`.env` ファイルを `.gitignore` に追加**
- 🛡️ **本番環境では環境変数で管理**
- 📝 **権限の少ないロールでテスト**

---

## 📊 使用例

### サーバーで大量スパムが発生した場合

```
1. !lock                    # チャンネルをロック
2. !clear 100               # スパムを削除
3. !slowmode 30              # スローモード設定
4. !ban @spammer テンポラリーバン
5. !unlock                  # ロック解除
```

### 問題のあるユーザーへの段階的対応

```
警告1: !warn @user 不適切な言葉

警告2: !warn @user 他ユーザーへの攻撃
      !mute @user 60 冷静になる時間

警告3: !warn @user 最終警告
       # 自動的にミュート

バン: !ban @user 規約違反
```

---

## 🎯 推奨設定

### サーバー初期設定

1. **moderation-logs チャンネルを作成**
   - ボットのログが自動投稿されます
   - モデレーションの履歴確認用

2. **Muted ロールを作成**（ボットが自動作成も可）
   - 全チャンネルでメッセージ送信禁止
   - ボイスチャット禁止

3. **モデレーター用ロールを設定**
   - Moderator（基本権限）
   - Senior Moderator（高度な権限）
   - Owner（全権限）

---

## 🔧 カスタマイズ

### 禁止ワードリストを編集

`discord_moderation_bot.py` の `load_bad_words()` メソッドを編集：

```python
def load_bad_words(self):
    default_bad_words = {
        'spam', 'badword1', 'badword2',
        # 追加のワードをここに入力
    }
    self.bad_words = default_bad_words
```

### スパム検出の感度を調整

`SpamDetector` クラスで各閾値を変更：

```python
# 例：メッセージスパムの基準を変更
if len(self.message_history[user_id]) > 3:  # 5から3に変更
    return True, "メッセージスパム"
```

詳細は `ADVANCED_CONFIG.md` を参照

---

## 🐛 トラブルシューティング

### Q: ボットが反応しない
**A:** 
- メッセージコンテンツ Intent が有効か確認
- Developer Portal → **Bot** → **Message Content Intent** をON

### Q: ミュート機能が動かない
**A:**
- Muted ロールが存在するか確認
- ボットのロールが Muted ロールより上か確認

### Q: トークンエラーが出る
**A:**
- `.env` ファイルが正しい場所にあるか確認
- トークンが正しく入力されているか確認
- トークンを再生成してみる

詳細は `SETUP_GUIDE.md` を参照

---

## 📈 今後の拡張案

- [ ] リアクション投票システム
- [ ] モデレーション統計ダッシュボード
- [ ] 高度なAIスパム検出
- [ ] ユーザーレピュテーションシステム
- [ ] 自動レスポンスメッセージ
- [ ] 複数言語対応
- [ ] Webダッシュボード

---

## 🤝 コントリビューション

改善提案やバグ報告は、IssuesやPull Requestsで受け付けています

---

## 📜 ライセンス

MIT License - 自由に使用・改変・配布できます

---

## 📞 サポート

問題が発生した場合：

1. `SETUP_GUIDE.md` のトラブルシューティングを確認
2. `COMMAND_EXAMPLES.md` で類似の例を探す
3. `ADVANCED_CONFIG.md` で設定を確認
4. Discord.py の公式ドキュメントを参照

---

## 🎉 おめでとうございます！

これであなたのサーバーは以下を備えた本格的なモデレーションシステムを装備しました：

✅ 自動スパム検出  
✅ 段階的な警告システム  
✅ 柔軟なミュート・バン機能  
✅ 禁止ワードフィルター  
✅ 完全なログ記録  
✅ 24時間の自動監視  

**安全で快適なコミュニティの構築をお祈りします！** 🚀

---

## 📚 参考リンク

- [discord.py Documentation](https://discordpy.readthedocs.io/)
- [Discord Developer Portal](https://discord.com/developers/)
- [Python Documentation](https://docs.python.org/3/)

---

**最終更新:** 2024年1月  
**バージョン:** 1.0  
**ステータス:** 本番環境対応
