# Discord 荒らし対策ボット セットアップガイド

## 📋 必要なもの

- Python 3.8以上
- Discord サーバー（管理者権限）
- Discord Bot トークン

---

## 🚀 インストール手順

### 1. Python ライブラリをインストール

```bash
pip install discord.py
```

### 2. Discord Developer Portal でボットを作成

1. [Discord Developer Portal](https://discord.com/developers/applications) にアクセス
2. **New Application** をクリック
3. ボット名を入力 → **Create**
4. **Bot** タブ → **Add Bot** をクリック
5. **TOKEN** の下にある **Copy** をクリック
6. `discord_moderation_bot.py` の `TOKEN = "YOUR_BOT_TOKEN_HERE"` を自分のトークンに置き換える

### 3. ボット権限を設定

1. Developer Portal で **OAuth2** → **URL Generator** に移動
2. **Scopes**: `bot` をチェック
3. **Permissions** で以下を選択：
   - ✅ Send Messages
   - ✅ Embed Links
   - ✅ Read Message History
   - ✅ Delete Messages
   - ✅ Manage Messages
   - ✅ Ban Members
   - ✅ Kick Members
   - ✅ Manage Roles
   - ✅ Manage Channels

4. 生成されたURLをブラウザで開き、ボットをサーバーに招待

### 4. ボットを起動

```bash
python discord_moderation_bot.py
```

---

## ✨ 実装されている全機能

### 🛡️ 自動荒らし対策
- **スパム検出**
  - 短時間の連続メッセージ
  - メンション スパム
  - Embed スパム
  - キャップスロック（大文字）連発
  - 絵文字スパム

- **禁止ワード フィルター**
  - 自動的に削除
  - ユーザーにDM通知

- **ユーザー プロフィール 記録**
  - 参加・退出ログ
  - アカウント情報保存

### ⚠️ 警告システム
```
!warn @user [理由]     # ユーザーに警告
!warnings [@user]      # 警告履歴を表示
```
- 3回の警告で自動ミュート
- タイムスタンプ付きで記録

### 🔇 ミュート機能
```
!mute @user [分] [理由]   # ユーザーをミュート
!unmute @user             # ミュートを解除
```
- 自動で Muted ロール作成
- 時間指定可能
- 期限切れで自動解除

### 🔨 バン・キック機能
```
!ban @user [時間] [理由]    # ユーザーをバン（永続または期間指定）
!kick @user [理由]          # ユーザーをキック
```
- 期間指定でのテンポラリーバン
- 自動期限切れ

### 🗑️ メッセージ管理
```
!clear [数]               # メッセージを削除（最大100件）
!slowmode [秒]            # スローモード設定（最大6時間）
```

### 🔒 チャンネル保護
```
!lock      # チャンネルをロック
!unlock    # チャンネルのロック解除
```

### 🔤 禁止ワード管理
```
!addbadword [ワード]      # 禁止ワードを追加
!removebadword [ワード]   # 禁止ワードを削除
```

### ℹ️ 情報表示
```
!info [@user]      # ユーザー情報（警告数含む）
!serverinfo        # サーバー情報
!help              # 全コマンド表示
```

---

## 📊 データ保存

ボットはモデレーション データを `moderation_data.json` に自動保存します：
- 警告履歴
- ミュート情報
- バン情報
- ユーザープロフィール

---

## ⚙️ カスタマイズ

### 禁止ワードを編集

`discord_moderation_bot.py` の `load_bad_words()` メソッドを編集：

```python
def load_bad_words(self):
    default_bad_words = {
        'spam', 'porn', 'xxx',  # 追加のワード
        'your_word_here'
    }
    self.bad_words = default_bad_words
```

### スパム検出の感度を調整

`SpamDetector` クラスの各チェック部分を編集：

```python
# 10秒以内のメッセージ制限を変更
if len(self.message_history[user_id]) > 5:  # 5を変更
    return True, "メッセージスパム"

# メンション数の制限を変更
if message.mentions and len(message.mentions) > 5:  # 5を変更
    ...
```

### ログチャンネルを作成

参加・退出ログを表示するため、以下の名前のチャンネルを作成：
```
moderation-logs
```

---

## 🔑 トラブルシューティング

### トークンエラー
- トークンが正しく入力されているか確認
- トークンを再生成してみる

### 権限エラー
- ボットのロールがサーバーで十分な権限を持っているか確認
- ボットを最上位に配置する（ロール管理 → ボットロール）

### コマンドが反応しない
- ボットがオンラインであることを確認
- メッセージコンテンツの意図を有効にしているか確認
  - Developer Portal → **Bot** → **Message Content Intent** をON

### モデレーション機能が動かない
- ボットに必要な権限があるか確認
- Python 3.8以上を使用しているか確認

---

## 📝 コマンド一覧（クイックリファレンス）

| コマンド | 説明 | 権限 |
|---------|------|------|
| `!warn` | 警告を与える | Manage Messages |
| `!mute` | ユーザーをミュート | Manage Roles |
| `!unmute` | ミュート解除 | Manage Roles |
| `!ban` | ユーザーをバン | Ban Members |
| `!kick` | ユーザーをキック | Kick Members |
| `!clear` | メッセージ削除 | Manage Messages |
| `!slowmode` | スローモード設定 | Manage Channels |
| `!lock` | チャンネルロック | Manage Channels |
| `!unlock` | ロック解除 | Manage Channels |
| `!warnings` | 警告履歴表示 | Manage Messages |
| `!info` | ユーザー情報 | なし |
| `!serverinfo` | サーバー情報 | なし |
| `!addbadword` | 禁止ワード追加 | Manage Messages |
| `!removebadword` | 禁止ワード削除 | Manage Messages |
| `!help` | ヘルプ表示 | なし |

---

## 🔐 セキュリティ注意事項

⚠️ **トークンを絶対に共有しないでください**

- トークンは秘密の環境変数に保存することをお勧めします
- `python-dotenv` を使用して `.env` ファイルから読み込む：

```python
from dotenv import load_dotenv
import os

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
bot.run(TOKEN)
```

`.env` ファイル:
```
DISCORD_TOKEN=your_token_here
```

---

## 💡 今後の拡張案

- リアクション投票システム
- 自動モデレーション統計ダッシュボード
- より高度なAIスパム検出
- ユーザーレピュテーションシステム
- 自動レスポンスメッセージ

---

質問や問題がある場合、Discord Developers公式ドキュメントを確認してください。
