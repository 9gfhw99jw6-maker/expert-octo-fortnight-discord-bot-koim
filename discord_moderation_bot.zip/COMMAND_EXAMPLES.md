# Discord 荒らし対策ボット - コマンド実行例

## 🎯 実際の使用シーン別ガイド

### シーン1: ユーザーが連続でスパムメッセージを送信

```
自動実行（手動対応不要）:
1. ボットが自動的にメッセージを削除
2. ユーザーにDMで警告を送信
3. 記録に追加

重大な場合は手動で対応:
!warn @SpamUser スパムメッセージ送信
!mute @SpamUser 30 スパム行為
```

---

### シーン2: 荒らしユーザーがサーバーに参加

```
対応手順:
1. ユーザー情報を確認
   !info @TrollUser

2. 怪しい場合はミュート
   !mute @TrollUser 120 新規ユーザーの初期確認

3. 確認後、ミュート解除
   !unmute @TrollUser

4. または、バンする（明らかに悪い場合）
   !ban @TrollUser 確認なし-明らかな荒らし
```

---

### シーン3: 禁止ワード対策

```
禁止ワードを追加:
!addbadword badword1
!addbadword badword2
!addbadword spam

禁止ワード削除（運営で許可した場合）:
!removebadword oldword

確認:
!help  # 現在の禁止ワードリストを確認
```

---

### シーン4: チャンネルが荒らしで混乱

```
緊急対応:
1. チャンネルをロック（新規メッセージ禁止）
   !lock

2. スパムメッセージを削除
   !clear 50  # 最新50件削除

3. スローモードを設定（各ユーザーの投稿間隔を制限）
   !slowmode 10  # 10秒間隔に制限

4. 落ち着いたらロック解除
   !unlock

5. スローモード解除
   !slowmode 0
```

---

### シーン5: 問題のあるユーザーを監視

```
ステップアップ方式:

【警告1】
!warn @ProblematicUser 不適切な言葉遣い

【警告2】
!warn @ProblematicUser 他ユーザーへの攻撃的な行動
!warnings @ProblematicUser  # 履歴確認

【警告3（自動ミュート）】
!warn @ProblematicUser 最終警告：規約違反

ボットが自動的に!mute を実行

【必要に応じてバン】
!ban @ProblematicUser 3日 警告3回 → 規約違反

---

### シーン6: 定期的なモデレーション確認

```
朝のチェック:
!serverinfo  # サーバーの状態確認
!stats       # モデレーション統計表示

問題のあるユーザーチェック:
!warnings @username  # 各ユーザーの警告履歴確認

ログ確認:
moderation-logs チャンネルで
- 参加/退出したユーザー
- 実行されたモデレーション
を確認
```

---

## 📋 コマンド一覧（詳細版）

### 警告システム

```bash
# ユーザーに警告を与える（理由は任意）
!warn @user reason
!warn @username スパム行為
!warn @user 不適切な言葉

# ユーザー（または自分）の警告履歴を表示
!warnings
!warnings @username
!warnings @user

# 警告回数を確認（ユーザー情報から）
!info @username
```

**警告システムの流れ:**
- 警告1回目: メッセージが送信される
- 警告2回目: メッセージが送信される
- 警告3回目: **自動的にミュートされる（60分）**

---

### ミュートシステム

```bash
# ユーザーをミュート（デフォルト60分）
!mute @user
!mute @user 120  # 120分
!mute @user 1440 理由テキスト  # 24時間

# 様々な期間でのミュート例
!mute @spammer 10 短時間の警告
!mute @user 180 3時間の反省時間
!mute @user 1440 24時間のミュート

# ミュートを解除
!unmute @user
!unmute @username
```

**ミュート状態:**
- メッセージ送信不可
- ボイスチャット発言不可
- 反応（リアクション）は可能

---

### バン・キックシステム

```bash
# ユーザーをキック（警告）
!kick @user
!kick @user 理由テキスト
!kick @user 他のサーバーで悪い評判

# 一時的なバン（期間指定）
!ban @user 24 24時間のテンポラリーバン
!ban @user 72 3日間のバン
!ban @user 168 1週間のバン

# 永続バン
!ban @user 理由テキスト
!ban @user 0 永続バン理由
!ban @user 対立的な行動を繰り返す

# バンの種類の使い分け
!kick @user  # まず警告として使用
!ban @user 24  # テスト期間を設ける
!ban @user  # 再犯時に永続バン
```

---

### メッセージ管理

```bash
# メッセージを一括削除
!clear  # 直前のメッセージ+10件を削除
!clear 20  # 直前20件を削除
!clear 100  # 最大100件を削除

# スローモードを設定（メッセージ送信間隔を制限）
!slowmode  # 解除
!slowmode 1  # 1秒間隔
!slowmode 5  # 5秒間隔
!slowmode 15  # 15秒間隔
!slowmode 60  # 1分間隔
!slowmode 300  # 5分間隔
!slowmode 3600  # 1時間間隔
!slowmode 21600  # 6時間間隔（最大）

# スローモード活用例
# イベント中のチャットスピードを落とす
!slowmode 3

# 荒らしが多い時
!slowmode 30

# 落ち着いたら解除
!slowmode 0
```

---

### チャンネル保護

```bash
# チャンネルを全員にロック（管理者を除く）
!lock

# 緊急ロック例
!slowmode 30  # まずスローモード
!lock  # ロック
!clear 100  # スパムを削除

# チャンネルをアンロック
!unlock

# ロック解除後
!slowmode 0  # スローモード解除
```

---

### 禁止ワード管理

```bash
# 禁止ワードを追加
!addbadword spam
!addbadword badword
!addbadword inappropriate

# 複数の禁止ワード
!addbadword shorturl  # 短縮URL
!addbadword clickhere  # 誘導リンク
!addbadword droplink  # 疑わしいリンク

# 禁止ワードを削除
!removebadword spam
!removebadword oldword

# 禁止ワード検出の流れ
# 1. ユーザーが禁止ワードを含むメッセージを送信
# 2. ボットが自動削除
# 3. ユーザーにDMで通知
# 4. 記録に追加（警告カウント）
```

---

### ユーザー・サーバー情報

```bash
# 自分の情報
!info
!info @user
!info @username

# 情報に含まれる内容
# - ID
# - ユーザータグ
# - アカウント作成日
# - サーバー参加日
# - ロール一覧
# - 警告数

# サーバー全体の情報
!serverinfo

# サーバー情報に含まれる内容
# - サーバーID
# - 所有者
# - メンバー数
# - チャンネル数
# - ロール数
# - 作成日

# ヘルプを表示
!help
```

---

## 🚨 緊急対応マニュアル

### 大量スパムが発生した場合

```
【即座に実行】
!lock  # チャンネルロック

【スパムを削除】
!clear 100  # 最後の100メッセージ削除

【スパマーを特定】
!info @suspected_spammer
!warnings @suspected_spammer

【対応】
!mute @spammer 60 スパム行為
または
!ban @spammer 24 テンポラリーバン

【チャンネル復旧】
!unlock  # ロック解除
!slowmode 0  # スローモード解除

【確認】
!help  # 通常動作確認
```

---

### 個人攻撃・荒らしが発生した場合

```
【証拠保存】
スクリーンショットを撮影

【ユーザー確認】
!info @troll_user

【即座の対応】
!warn @troll_user 他ユーザーへの攻撃的行動
!mute @troll_user 120 攻撃的な行動

【繰り返す場合】
!warn @troll_user 最終警告
!ban @troll_user 規約違反

【フォロー】
moderation-logs チャンネルで対応を確認
```

---

### 新規ユーザーの大量参加（可能性のあるRAID）

```
【防衛モード】
!slowmode 30  # 新規メッセージを制限

【ユーザーを監視】
join messages を確認

【怪しいユーザーを特定】
!info @new_user_1
!info @new_user_2

【対応】
!mute @suspicious_user 180 新規ユーザー確認
または
!ban @suspicious_user 24 不審なアクティビティ

【落ち着いたら】
!slowmode 0
```

---

## 💡 ベストプラクティス

### ✅ 推奨される運用方法

```
1. 警告は明確な理由を付ける
   ✓ !warn @user スパムメッセージ
   ✗ !warn @user

2. 段階的な対応をする
   ✓ 警告 → ミュート → バン
   ✗ 最初からバン

3. 定期的に moderation-logs を確認
   ✓ 毎日チェック
   ✗ 放置

4. 複数のモデレーターで対応を共有
   ✓ 決定を moderation-logs に記録
   ✗ DM で秘密裏に対応

5. ユーザーに理由を伝える
   ✓ !mute @user 120 理由を記入
   ✗ 理由なしにミュート
```

---

### ❌ 避けるべき運用方法

```
✗ 感情的な判断でバン
✗ 一度の違反で永続バン
✗ モデレーション記録をしない
✗ ルールを曖昧にする
✗ モデレーターの権力濫用
✗ ユーザーへの明確な説明がない
```

---

## 📊 実行例の統計

### 「良好なサーバー」の1ヶ月のモデレーション

```
メンバー数: 1000人

警告: 8件 (0.8%)
ミュート: 3件 (0.3%)
バン: 1件 (0.1%)
自動削除: 24件 (スパム・禁止ワード)

= 非常に健全なコミュニティ状態
```

### 「問題があるサーバー」の1ヶ月のモデレーション

```
メンバー数: 1000人

警告: 45件 (4.5%)
ミュート: 18件 (1.8%)
バン: 5件 (0.5%)
自動削除: 200件以上

= 対応が必要な状態
= ルールの見直しと強化を検討
```

---

このガイドを参考に、効果的なモデレーションを行ってください！
